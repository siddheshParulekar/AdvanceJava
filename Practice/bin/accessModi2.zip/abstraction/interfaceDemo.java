package abstraction;

import java.awt.print.Printable;

public interface interfaceDemo {
	int a = 10;

	void draw();

//	 protected void msg() {
//		System.out.println("hello");
//	}
	public static void hello() {
		System.out.println("heloooooo");
	}

	default void Printable() {
		System.out.println("printingtable");
		// msg();
	}
}
