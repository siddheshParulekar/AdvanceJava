package abstraction;

abstract class demo {

	public demo() {
		super();

		System.out.println("Inside abstract constructor");
		
	}

	abstract void run1();
	
	void heloo() {
		System.out.println("Hellooooo");
	}

	public static void chor() {
		System.out.println("Static method");
	}

}

class fun extends demo {

	@Override
	void run1() {
		System.out.println("Overriding method");
	}

}

public class abstractclass {

	public static void main(String[] args) {

		//creating object of demo class using annonymous class
//		demo do1 = new demo() {
//			
//			@Override
//			void run1() {
//				// TODO Auto-generated method stub
//				
//			}
//		};
		
		demo d1 = new fun();
		d1.heloo();
		fun f1 = new fun();
		demo.chor();
		f1.run1();

	}

}
