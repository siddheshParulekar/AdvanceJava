package accessModi;

public class Class3 extends Class1 {

	public static void main(String[] args) {
		Class1 class1 = new Class3();
		class1.demo1();
		System.out.println(class1.a);
	}
}
