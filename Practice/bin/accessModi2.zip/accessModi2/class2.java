package accessModi2;

import accessModi.Class1;

public class class2 extends Class1 {
	
	public static void main(String[] args) {
		class2 oj2 = new class2();
		
		oj2.demo();
		oj2.demo1();
		
	}

}
